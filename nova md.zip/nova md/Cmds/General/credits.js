//credits.js

/* Why do you want to edit the credits ?, You may add yourself but do not OMIT any part */




module.exports = async (context) => {
    const { client, m, prefix } = context;


           await client.sendMessage(m.chat, { image: { url: 'https://i.ibb.co/tpzz0D1Y/nova.jpg' }, caption: `We express sincere gratitude and acknowledgement to the following:\n\n -MX GAMECODER ➪ Nigeria\n - Writing the base code using case method\nhttps://github.com/themxgamecoder\n\n -Adiwajshing ➪ India\n - Writing and Coding the bot's library (baileys)\nhttps://github.com/WhiskeySockets/Baileys\n\n -WAWebSockets Discord Server community\n-Maintaining and reverse engineering the Web Sockets\nhttps://discord.gg/WeJM5FP9GG\n\n - AthenaTech ➪ Nigeria\n - Actively compiling and debugging parts of this bot script\nhttps://chat.whatsapp.com/GS6oBbA80sc9HO7Tq4SDyJ\n - AthenaTech ➪ Nigeria\n - Actively de-compiling, debugging and fixing parts of this bot script\nhttps://i.ibb.co/tpzz0D1Y/nova.jpg\n\n - ChatGPT ➪ USA\n - Formulating ideas and assisting in debugging.\nhttps://chat.openai.com\n\nNOVA MD シ︎`}); 


}

/* Do not edit this credits, Do not delete */